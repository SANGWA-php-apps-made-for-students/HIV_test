
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
, `account_category`     int(11)   
,`date_created`     Date 
, `profile`     int(11)   
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`is_online`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
, `image`     int(11)   

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
`image_id`     int(11) NOT NULL AUTO_INCREMENT 
,`path`     VARCHAR(60) 

,PRIMARY KEY (`image_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `Doctor`
--

CREATE TABLE IF NOT EXISTS `Doctor` (
`Doctor_id`     int(11) NOT NULL AUTO_INCREMENT 
,`education_bgnd`     VARCHAR(60) 
,`specialization`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`Doctor_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `lab_tech`
--

CREATE TABLE IF NOT EXISTS `lab_tech` (
`lab_tech_id`     int(11) NOT NULL AUTO_INCREMENT 
,`education_bgnd`     VARCHAR(60) 
,`specialization`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 

,PRIMARY KEY (`lab_tech_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `diagnosis`
--

CREATE TABLE IF NOT EXISTS `diagnosis` (
`diagnosis_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `reception`     int(11)   

,PRIMARY KEY (`diagnosis_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `test`
--

CREATE TABLE IF NOT EXISTS `test` (
`test_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`result`     VARCHAR(60) 
,`comment`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `diagnosis`     int(11)   

,PRIMARY KEY (`test_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `reception`
--

CREATE TABLE IF NOT EXISTS `reception` (
`reception_id`     int(11) NOT NULL AUTO_INCREMENT 
, `patient`     int(11)   
,`new_existing`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
,`treated_not_treated`     VARCHAR(60) 

,PRIMARY KEY (`reception_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `diagnosis_symptoms`
--

CREATE TABLE IF NOT EXISTS `diagnosis_symptoms` (
`diagnosis_symptoms_id`     int(11) NOT NULL AUTO_INCREMENT 
, `diagnosis`     int(11)   
, `symptom`     int(11)   

,PRIMARY KEY (`diagnosis_symptoms_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `symptoms`
--

CREATE TABLE IF NOT EXISTS `symptoms` (
`symptoms_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 
,`description`     VARCHAR(60) 

,PRIMARY KEY (`symptoms_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
`appointment_id`     int(11) NOT NULL AUTO_INCREMENT 
,`entry_date`     Date 
, `profile`     int(11)   

,PRIMARY KEY (`appointment_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

