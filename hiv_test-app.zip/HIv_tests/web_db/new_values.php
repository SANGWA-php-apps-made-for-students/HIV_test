<?php

class new_values {

    function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
            $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_account_category($name) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
            $stm->execute(array(':account_category_id' => 0, ':name' => $name
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
            $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_image($path) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into image values(:image_id, :path)");
            $stm->execute(array(':image_id' => 0, ':path' => $path
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_Doctor($education_bgnd, $specialization, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into Doctor values(:Doctor_id, :education_bgnd,  :specialization,  :entry_date,  :User)");
            $stm->execute(array(':Doctor_id' => 0, ':education_bgnd' => $education_bgnd, ':specialization' => $specialization, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_lab_tech($education_bgnd, $specialization, $entry_date, $User) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into lab_tech values(:lab_tech_id, :education_bgnd,  :specialization,  :entry_date,  :User)");
            $stm->execute(array(':lab_tech_id' => 0, ':education_bgnd' => $education_bgnd, ':specialization' => $specialization, ':entry_date' => $entry_date, ':User' => $User
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_diagnosis($entry_date, $User, $reception) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into diagnosis values(:diagnosis_id, :entry_date,  :User,  :reception)");
            $stm->execute(array(':diagnosis_id' => 0, ':entry_date' => $entry_date, ':User' => $User, ':reception' => $reception
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_test($name, $result, $comment, $entry_date, $User, $diagnosis) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into test values(:test_id, :name,  :result,  :comment,  :entry_date,  :User,  :diagnosis)");
            $stm->execute(array(':test_id' => 0, ':name' => $name, ':result' => $result, ':comment' => $comment, ':entry_date' => $entry_date, ':User' => $User, ':diagnosis' => $diagnosis
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_reception($patient, $new_existing, $entry_date, $User, $treated_not_treated) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into reception values(:reception_id, :patient,  :new_existing,  :entry_date,  :User,  :treated_not_treated)");
            $stm->execute(array(':reception_id' => 0, ':patient' => $patient, ':new_existing' => $new_existing, ':entry_date' => $entry_date, ':User' => $User, ':treated_not_treated' => $treated_not_treated
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_diagnosis_symptoms($diagnosis, $symptom) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into diagnosis_symptoms values(:diagnosis_symptoms_id, :diagnosis,  :symptom)");
            $stm->execute(array(':diagnosis_symptoms_id' => 0, ':diagnosis' => $diagnosis, ':symptom' => $symptom
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_symptoms($name, $description) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into symptoms values(:symptoms_id, :name,  :description)");
            $stm->execute(array(':symptoms_id' => 0, ':name' => $name, ':description' => $description
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function new_appointment($entry_date, $profile) {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stm = $db->prepare("insert into appointment values(:appointment_id, :entry_date,  :profile)");
            $stm->execute(array(':appointment_id' => 0, ':entry_date' => $entry_date, ':profile' => $profile
            ));
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

}
