<?php
 session_start();

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}
if (isset($_POST['cbo_image'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
    return $id;
}
if (isset($_POST['cbo_reception'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_reception_id_by_reception_name($_POST['cbo_reception']);
    return $id;
}
if (isset($_POST['cbo_diagnosis'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_diagnosis_id_by_diagnosis_name($_POST['cbo_diagnosis']);
    return $id;
}
if (isset($_POST['cbo_patient'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_patient_id_by_patient_name($_POST['cbo_patient']);
    return $id;
}
if (isset($_POST['cbo_diagnosis'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_diagnosis_id_by_diagnosis_name($_POST['cbo_diagnosis']);
    return $id;
}
if (isset($_POST['cbo_symptom'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_symptom_id_by_symptom_name($_POST['cbo_symptom']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
    return $id;
}

if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from account
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);}
//The Delete from account_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account_category($id);}
//The Delete from profile
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);}
//The Delete from image
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_image($id);}
//The Delete from Doctor
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'Doctor') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_Doctor($id);}
//The Delete from lab_tech
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'lab_tech') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_lab_tech($id);}
//The Delete from diagnosis
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'diagnosis') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_diagnosis($id);}
//The Delete from test
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'test') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_test($id);}
//The Delete from reception
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'reception') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_reception($id);}
//The Delete from diagnosis_symptoms
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'diagnosis_symptoms') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_diagnosis_symptoms($id);}
//The Delete from symptoms
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'symptoms') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_symptoms($id);}
//The Delete from appointment
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'appointment') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_appointment($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
account_del_udpate();
account_category_del_udpate();
profile_del_udpate();
image_del_udpate();
Doctor_del_udpate();
lab_tech_del_udpate();
diagnosis_del_udpate();
test_del_udpate();
reception_del_udpate();
diagnosis_symptoms_del_udpate();
symptoms_del_udpate();
appointment_del_udpate();

