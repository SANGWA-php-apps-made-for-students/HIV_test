<div class="parts  eighty_centered ">            <div class="parts  no_paddin_shade_no_Border xxx_titles">
                Hiv
            </div>
</div>        <div class="parts menu eighty_centered">
<a href="new_account.php">account</a>
<a href="new_account_category.php">account_category</a>
<a href="new_profile.php">profile</a>
<a href="new_image.php">image</a>
<a href="new_Doctor.php">Doctor</a>
<a href="new_lab_tech.php">lab_tech</a>
<a href="new_diagnosis.php">diagnosis</a>
<a href="new_test.php">test</a>
<a href="new_reception.php">reception</a>
<a href="new_diagnosis_symptoms.php">diagnosis_symptoms</a>
<a href="new_symptoms.php">symptoms</a>
<a href="new_appointment.php">appointment</a>

  <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
                <a href="login.php">Login</a>
            </div>
       </div>
