<?php

require_once 'connection.php';

class updates {

    function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
        $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
    }

    function update_account_category($name, $account_category_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
        $stmt->execute(array($name, $account_category_id));
    }

    function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
        $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
    }

    function update_image($path, $image_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
        $stmt->execute(array($path, $image_id));
    }

    function update_Doctor($education_bgnd, $specialization, $entry_date, $User, $Doctor_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE Doctor set 
education_bgnd= ?, specialization= ?, entry_date= ?, User= ? WHERE Doctor_id=?");
        $stmt->execute(array($education_bgnd, $specialization, $entry_date, $User, $Doctor_id));
    }

    function update_lab_tech($education_bgnd, $specialization, $entry_date, $User, $lab_tech_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE lab_tech set 
education_bgnd= ?, specialization= ?, entry_date= ?, User= ? WHERE lab_tech_id=?");
        $stmt->execute(array($education_bgnd, $specialization, $entry_date, $User, $lab_tech_id));
    }

    function update_diagnosis($entry_date, $User, $reception, $diagnosis_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE diagnosis set 
entry_date= ?, User= ?, reception= ? WHERE diagnosis_id=?");
        $stmt->execute(array($entry_date, $User, $reception, $diagnosis_id));
    }

    function update_test($name, $result, $comment, $entry_date, $User, $diagnosis, $test_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE test set 
name= ?, result= ?, comment= ?, entry_date= ?, User= ?, diagnosis= ? WHERE test_id=?");
        $stmt->execute(array($name, $result, $comment, $entry_date, $User, $diagnosis, $test_id));
    }

    function update_reception($patient, $new_existing, $entry_date, $User, $treated_not_treated, $reception_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE reception set 
patient= ?, new_existing= ?, entry_date= ?, User= ?, treated_not_treated= ? WHERE reception_id=?");
        $stmt->execute(array($patient, $new_existing, $entry_date, $User, $treated_not_treated, $reception_id));
    }

    function update_reception_treated($treated_not_treated, $reception_id) {
        try {
            $database = new dbconnection();
            $db = $database->openconnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $db->prepare("UPDATE reception set  treated_not_treated= ? WHERE reception_id=?");
            $stmt->execute(array($treated_not_treated, $reception_id));
           
        } catch (PDOException $e) {
            echo 'Error .. ' . $e->getMessage();
        }
    }

    function update_diagnosis_symptoms($diagnosis, $symptom, $diagnosis_symptoms_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE diagnosis_symptoms set 
diagnosis= ?, symptom= ? WHERE diagnosis_symptoms_id=?");
        $stmt->execute(array($diagnosis, $symptom, $diagnosis_symptoms_id));
    }

    function update_symptoms($name, $description, $symptoms_id) {
        $database = new dbconnection();
        $db = $database->openconnection();
        $stmt = $db->prepare("UPDATE symptoms set 
name= ?, description= ? WHERE symptoms_id=?");
        $stmt->execute(array($name, $description, $symptoms_id));
    }

}
