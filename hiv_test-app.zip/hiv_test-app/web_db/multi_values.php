<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        if ($_SESSION['cat'] == 'admin') {
            $sql = "select account.account_id,  account.account_category,  account.date_created,  account.profile,  account.username,  account.password,  profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence, account_category.name as cat"
                    . " from account "
                    . "join account_category "
                    . " on account_category.account_category_id=account.account_category "
                    . "  join profile on account.profile = profile.profile_id "
                    . " where account_category.name='" . $_SESSION['menu_user'] . "'";
        } else {

            $sql = "select account.account_id,  account.account_category,  account.date_created,  account.profile,  account.username,  account.password,  profile.profile_id,  profile.dob,  profile.name,  profile.last_name,  profile.gender,  profile.telephone_number,  profile.email,  profile.residence, account_category.name as cat"
                    . " from account "
                    . "join account_category "
                    . " on account_category.account_category_id=account.account_category "
                    . "  join profile on account.profile = profile.profile_id  "
                    . " where account_category.name='" . $_SESSION['cat'] . "'";
        }

        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account </td>
                    <td>Names  </td><td>Date  </td> <td> Email </td>
                    <?php if ($_SESSION['cat'] == 'admin') { ?>   
                        <td> password </td>
                    <?php } ?>  

                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_id']; ?>
                    </td>
                    <td class="account_category_id_cols account " title="account" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['date_created']); ?>
                    </td>                       
                    <td>
                        <?php echo $this->_e($row['username']); ?>
                    </td>
                    <?php if ($_SESSION['cat'] == 'admin') { ?>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                    <?php } ?>
                    <td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id']; ?>"  data-table="account">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_account_category($id) {

            $db = new dbconnection();
            $sql = "select   account.account_category from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['account_category'];
            echo $field;
        }

        function get_chosen_account_date_created($id) {

            $db = new dbconnection();
            $sql = "select   account.date_created from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['date_created'];
            echo $field;
        }

        function get_chosen_account_profile($id) {

            $db = new dbconnection();
            $sql = "select   account.profile from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function get_chosen_account_username($id) {

            $db = new dbconnection();
            $sql = "select   account.username from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['username'];
            echo $field;
        }

        function get_chosen_account_password($id) {

            $db = new dbconnection();
            $sql = "select   account.password from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['password'];
            echo $field;
        }

        function get_chosen_account_is_online($id) {

            $db = new dbconnection();
            $sql = "select   account.is_online from account where account_id=:account_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['is_online'];
            echo $field;
        }

        function All_account() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_id   from account";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function get_last_account() {
            $con = new dbconnection();
            $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_id'];
            return $first_rec;
        }

        function list_account_category($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account_category";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> account_category </td>
                    <td> Category </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['account_category_id']; ?>
                    </td>
                    <td class="name_id_cols account_category " title="account_category" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>


                    <td>
                        <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_category_id']; ?>"  data-table="account_category">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="account_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_category_id']; ?>" data-table="account_category" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_account_category_name($id) {

            $db = new dbconnection();
            $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':account_category_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function All_account_category() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  account_category_id   from account_category";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function get_last_account_category() {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['account_category_id'];
            return $first_rec;
        }

        function list_profile($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> profile </td>
                    <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="dob_id_cols profile " title="profile" >
                        <?php echo $this->_e($row['dob']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['gender']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['telephone_number']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['email']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['residence']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['image']); ?>
                    </td>


                    <td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id']; ?>"  data-table="profile">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_profile_dob($id) {

            $db = new dbconnection();
            $sql = "select   profile.dob from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['dob'];
            echo $field;
        }

        function get_chosen_profile_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_profile_last_name($id) {

            $db = new dbconnection();
            $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['last_name'];
            echo $field;
        }

        function get_chosen_profile_gender($id) {

            $db = new dbconnection();
            $sql = "select   profile.gender from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['gender'];
            echo $field;
        }

        function get_chosen_profile_telephone_number($id) {

            $db = new dbconnection();
            $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['telephone_number'];
            echo $field;
        }

        function get_chosen_profile_email($id) {

            $db = new dbconnection();
            $sql = "select   profile.email from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['email'];
            echo $field;
        }

        function get_chosen_profile_residence($id) {

            $db = new dbconnection();
            $sql = "select   profile.residence from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['residence'];
            echo $field;
        }

        function get_chosen_profile_image($id) {

            $db = new dbconnection();
            $sql = "select   profile.image from profile where profile_id=:profile_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':profile_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['image'];
            echo $field;
        }

        function All_profile() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  profile_id   from profile";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function get_last_profile() {
            $con = new dbconnection();
            $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['profile_id'];
            return $first_rec;
        }

        function list_image($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from image";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> image </td>
                    <td>  </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['image_id']; ?>
                    </td>
                    <td class="path_id_cols image " title="image" >
                        <?php echo $this->_e($row['path']); ?>
                    </td>


                    <td>
                        <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['image_id']; ?>"  data-table="image">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="image_update_link" style="color: #000080;" data-id_update="<?php echo $row['image_id']; ?>" data-table="image" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_image_path($id) {

            $db = new dbconnection();
            $sql = "select   image.path from image where image_id=:image_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':image_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['path'];
            echo $field;
        }

        function All_image() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  image_id   from image";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function get_last_image() {
            $con = new dbconnection();
            $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['image_id'];
            return $first_rec;
        }

        function list_Doctor($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from doctor "
                    . " join account on account.account_id =doctor.User "
                    . " join profile on account.profile = profile.profile_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> Doctor </td>
                    <td> Names</td>
                    <td> Education Background </td><td> Specialization </td><td> Entry Date </td><td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>  <?php echo $row['Doctor_id']; ?>     </td>
                    <td>  <?php echo $row['name'].' '.$row['last_name']; ?>     </td>
                    <td class="education_bgnd_id_cols Doctor " title="Doctor" >
                        <?php echo $this->_e($row['education_bgnd']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['specialization']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['name']. ''.$row['last_name']); ?>
                    </td>


                    <td>
                        <a href="#" class="Doctor_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['Doctor_id']; ?>"  data-table="Doctor">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="Doctor_update_link" style="color: #000080;" data-id_update="<?php echo $row['Doctor_id']; ?>" data-table="Doctor" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_Doctor_education_bgnd($id) {

            $db = new dbconnection();
            $sql = "select   Doctor.education_bgnd from Doctor where Doctor_id=:Doctor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':Doctor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['education_bgnd'];
            echo $field;
        }

        function get_chosen_Doctor_specialization($id) {

            $db = new dbconnection();
            $sql = "select   Doctor.specialization from Doctor where Doctor_id=:Doctor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':Doctor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['specialization'];
            echo $field;
        }

        function get_chosen_Doctor_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   Doctor.entry_date from Doctor where Doctor_id=:Doctor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':Doctor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_Doctor_User($id) {

            $db = new dbconnection();
            $sql = "select   Doctor.User from Doctor where Doctor_id=:Doctor_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':Doctor_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_Doctor() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  Doctor_id   from Doctor";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_Doctor() {
            $con = new dbconnection();
            $sql = "select Doctor.Doctor_id from Doctor
                    order by Doctor.Doctor_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['Doctor_id'];
            return $first_rec;
        }

        function get_last_Doctor() {
            $con = new dbconnection();
            $sql = "select Doctor.Doctor_id from Doctor
                    order by Doctor.Doctor_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['Doctor_id'];
            return $first_rec;
        }

        function list_lab_tech($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from lab_tech "
                      . " join account on account.account_id =lab_tech.User "
                    . " join profile on account.profile = profile.profile_id ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead>
                <tr>
                    <td> Nurse ID </td>
                    <td> Names</td>
                    <td> Education Background </td><td> Specialization </td><td> Entry Date </td><td> User </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['lab_tech_id']; ?>
                    </td>
                     <td>  <?php echo $row['name'].' '.$row['last_name']; ?>     </td>
                    <td class="education_bgnd_id_cols lab_tech " title="lab_tech" >
                        <?php echo $this->_e($row['education_bgnd']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['specialization']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>


                    <td>
                        <a href="#" class="lab_tech_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['lab_tech_id']; ?>"  data-table="lab_tech">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="lab_tech_update_link" style="color: #000080;" data-id_update="<?php echo $row['lab_tech_id']; ?>" data-table="lab_tech" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_lab_tech_education_bgnd($id) {

            $db = new dbconnection();
            $sql = "select   lab_tech.education_bgnd from lab_tech where lab_tech_id=:lab_tech_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lab_tech_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['education_bgnd'];
            echo $field;
        }

        function get_chosen_lab_tech_specialization($id) {

            $db = new dbconnection();
            $sql = "select   lab_tech.specialization from lab_tech where lab_tech_id=:lab_tech_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lab_tech_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['specialization'];
            echo $field;
        }

        function get_chosen_lab_tech_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   lab_tech.entry_date from lab_tech where lab_tech_id=:lab_tech_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lab_tech_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_lab_tech_User($id) {

            $db = new dbconnection();
            $sql = "select   lab_tech.User from lab_tech where lab_tech_id=:lab_tech_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':lab_tech_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function All_lab_tech() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  lab_tech_id   from lab_tech";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_lab_tech() {
            $con = new dbconnection();
            $sql = "select lab_tech.lab_tech_id from lab_tech
                    order by lab_tech.lab_tech_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['lab_tech_id'];
            return $first_rec;
        }

        function get_last_lab_tech() {
            $con = new dbconnection();
            $sql = "select lab_tech.lab_tech_id from lab_tech
                    order by lab_tech.lab_tech_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['lab_tech_id'];
            return $first_rec;
        }

        function list_diagnosis($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from diagnosis";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> diagnosis </td>
                    <td> Entry Date </td><td> User </td><td> Reception </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['diagnosis_id']; ?>
                    </td>
                    <td class="entry_date_id_cols diagnosis " title="diagnosis" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['User']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['reception']); ?>
                    </td>


                    <td>
                        <a href="#" class="diagnosis_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['diagnosis_id']; ?>"  data-table="diagnosis">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="diagnosis_update_link" style="color: #000080;" data-id_update="<?php echo $row['diagnosis_id']; ?>" data-table="diagnosis" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_diagnosis_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   diagnosis.entry_date from diagnosis where diagnosis_id=:diagnosis_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':diagnosis_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_diagnosis_User($id) {

            $db = new dbconnection();
            $sql = "select   diagnosis.User from diagnosis where diagnosis_id=:diagnosis_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':diagnosis_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_diagnosis_reception($id) {

            $db = new dbconnection();
            $sql = "select   diagnosis.reception from diagnosis where diagnosis_id=:diagnosis_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':diagnosis_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['reception'];
            echo $field;
        }

        function All_diagnosis() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  diagnosis_id   from diagnosis";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_diagnosis() {
            $con = new dbconnection();
            $sql = "select diagnosis.diagnosis_id from diagnosis
                    order by diagnosis.diagnosis_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['diagnosis_id'];
            return $first_rec;
        }

        function get_last_diagnosis() {
            $con = new dbconnection();
            $sql = "select diagnosis.diagnosis_id from diagnosis
                    order by diagnosis.diagnosis_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['diagnosis_id'];
            return $first_rec;
        }

        function list_test($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT diagnosis.diagnosis_id,  diagnosis.entry_date,  diagnosis.User,  diagnosis.reception ,
                profile.profile_id,  profile.name,  profile.last_name,
                test.test_id,  test.name as test,  test.result,  test.comment
                FROM hiv_test.reception
                join diagnosis on diagnosis.reception=reception.reception_id
                join profile on profile.profile_id=reception.patient 
                join test on test.diagnosis=diagnosis.diagnosis_id";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> test </td>
                    <td> Name </td><td> Result </td><td> Comment </td><td> Entry Date </td> <td> Patient </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['test_id']; ?>
                    </td>
                    <td class="name_id_cols test " title="test" >
                        <?php echo $this->_e($row['test']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['result']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['comment']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>


                    <td>
                        <a href="#" class="test_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['test_id']; ?>"  data-table="test">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="test_update_link" style="color: #000080;" data-id_update="<?php echo $row['test_id']; ?>" data-table="test" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_test_name($id) {

            $db = new dbconnection();
            $sql = "select   test.name from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['name'];
            echo $field;
        }

        function get_chosen_test_result($id) {

            $db = new dbconnection();
            $sql = "select   test.result from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['result'];
            echo $field;
        }

        function get_chosen_test_comment($id) {

            $db = new dbconnection();
            $sql = "select   test.comment from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['comment'];
            echo $field;
        }

        function get_chosen_test_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   test.entry_date from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_test_User($id) {

            $db = new dbconnection();
            $sql = "select   test.User from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['User'];
            echo $field;
        }

        function get_chosen_test_diagnosis($id) {

            $db = new dbconnection();
            $sql = "select   test.diagnosis from test where test_id=:test_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':test_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['diagnosis'];
            echo $field;
        }

        function All_test() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  test_id   from test";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_test() {
            $con = new dbconnection();
            $sql = "select test.test_id from test
                    order by test.test_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['test_id'];
            return $first_rec;
        }

        function get_last_test() {
            $con = new dbconnection();
            $sql = "select test.test_id from test
                    order by test.test_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['test_id'];
            return $first_rec;
        }

        function list_reception($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from reception "
                    . " join profile on profile.profile_id=reception.patient ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> reception </td>
                    <td> Patient </td> 
                    <td> Entry Date </td>
                    <td> Treated Or Not </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['reception_id']; ?>
                    </td>
                    <td class="patient_id_cols reception " title="reception" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['treated_not_treated']); ?>
                    </td>


                    <td>
                        <a href="#" class="reception_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['reception_id']; ?>"  data-table="reception">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="reception_update_link" style="color: #000080;" data-id_update="<?php echo $row['reception_id']; ?>" data-table="reception" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

        function list_reception_by_profile($proflei) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from reception "
                    . " join profile on profile.profile_id=reception.patient "
                    . " where profile.profile_id=:profile";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":profile" => $proflei));
            ?>
        <table class="dataList_table">
            <thead><tr>
                    <td> reception </td>
                    <td> Patient </td> 
                    <td> Entry Date </td>
                    <td> Treated Or Not </td>

                </tr>
            </thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['reception_id']; ?>
                    </td>
                    <td class="patient_id_cols reception " title="reception" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>

                    <td>
                        <?php echo $this->_e($row['treated_not_treated']); ?>
                    </td>

                </tr>
                <?php
                $pages += 1;
            }
            ?></table>
        <?php
    }

//chosen individual field
    function get_chosen_reception_patient($id) {

        $db = new dbconnection();
        $sql = "select   reception.patient from reception where reception_id=:reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['patient'];
        echo $field;
    }

    function get_chosen_reception_new_existing($id) {

        $db = new dbconnection();
        $sql = "select   reception.new_existing from reception where reception_id=:reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['new_existing'];
        echo $field;
    }

    function get_chosen_reception_entry_date($id) {

        $db = new dbconnection();
        $sql = "select   reception.entry_date from reception where reception_id=:reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    }

    function get_chosen_reception_User($id) {

        $db = new dbconnection();
        $sql = "select   reception.User from reception where reception_id=:reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    }

    function get_chosen_reception_treated_not_treated($id) {

        $db = new dbconnection();
        $sql = "select   reception.treated_not_treated from reception where reception_id=:reception_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':reception_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['treated_not_treated'];
        echo $field;
    }

    function All_reception() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  reception_id   from reception";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_reception() {
        $con = new dbconnection();
        $sql = "select reception.reception_id from reception
                    order by reception.reception_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['reception_id'];
        return $first_rec;
    }

    function get_last_reception() {
        $con = new dbconnection();
        $sql = "select reception.reception_id from reception
                    order by reception.reception_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['reception_id'];
        return $first_rec;
    }

    function list_diagnosis_symptoms($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select diagnosis_symptoms.diagnosis_symptoms_id, diagnosis.diagnosis_id,  diagnosis.entry_date as diagnosis,  diagnosis.User,  diagnosis.reception,  symptoms.symptoms_id,  symptoms.name as symptom,profile.name,  profile.last_name"
                . " from diagnosis_symptoms"
                . "   join diagnosis on diagnosis_symptoms.diagnosis = diagnosis.diagnosis_id 
                        join reception on diagnosis.reception=reception. reception_id
                        join profile on profile.profile_id=reception.patient
                        join symptoms on symptoms.symptoms_id=diagnosis_symptoms.symptom
                            "
                . " ";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> S/N </td>
                    <td> Diagnosis Date</td><td> Patient </td><td> Symptoms </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['diagnosis_symptoms_id']; ?>
                    </td>
                    <td class="diagnosis_id_cols diagnosis_symptoms " title="diagnosis_symptoms" >
                        <?php echo $this->_e($row['diagnosis']); ?>
                    </td>
                    <td class="diagnosis_id_cols diagnosis_symptoms " title="diagnosis_symptoms" >
                        <?php echo $this->_e($row['name'] . ' ' . $row['last_name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['symptom']); ?>
                    </td>


                    <td>
                        <a href="#" class="diagnosis_symptoms_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['diagnosis_symptoms_id']; ?>"  data-table="diagnosis_symptoms">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="diagnosis_symptoms_update_link" style="color: #000080;" data-id_update="<?php echo $row['diagnosis_symptoms_id']; ?>" data-table="diagnosis_symptoms" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_diagnosis_symptoms_diagnosis($id) {

            $db = new dbconnection();
            $sql = "select   diagnosis_symptoms.diagnosis from diagnosis_symptoms where diagnosis_symptoms_id=:diagnosis_symptoms_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':diagnosis_symptoms_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['diagnosis'];
            echo $field;
        }

        function get_chosen_diagnosis_symptoms_symptom($id) {

            $db = new dbconnection();
            $sql = "select   diagnosis_symptoms.symptom from diagnosis_symptoms where diagnosis_symptoms_id=:diagnosis_symptoms_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':diagnosis_symptoms_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['symptom'];
            echo $field;
        }

        function All_diagnosis_symptoms() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  diagnosis_symptoms_id   from diagnosis_symptoms";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_diagnosis_symptoms() {
            $con = new dbconnection();
            $sql = "select diagnosis_symptoms.diagnosis_symptoms_id from diagnosis_symptoms
                    order by diagnosis_symptoms.diagnosis_symptoms_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['diagnosis_symptoms_id'];
            return $first_rec;
        }

        function get_last_diagnosis_symptoms() {
            $con = new dbconnection();
            $sql = "select diagnosis_symptoms.diagnosis_symptoms_id from diagnosis_symptoms
                    order by diagnosis_symptoms.diagnosis_symptoms_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['diagnosis_symptoms_id'];
            return $first_rec;
        }

        function list_symptoms($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from symptoms";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> symptoms </td>
                    <td> Name </td><td> Description </td>
                    <?php if ($_SESSION['cat'] == 'doctor') { ?> <td>Delete</td><td>Update</td><?php } ?></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['symptoms_id']; ?>
                    </td>
                    <td class="name_id_cols symptoms " title="symptoms" >
                        <?php echo $this->_e($row['name']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['description']); ?>
                    </td>

                    <?php if ($_SESSION['cat'] == 'doctor') { ?>
                        <td>
                            <a href="#" class="symptoms_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['symptoms_id']; ?>"  data-table="symptoms">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="symptoms_update_link" style="color: #000080;" data-id_update="<?php echo $row['symptoms_id']; ?>" data-table="symptoms" >Update</a>
                        </td> <?php } ?></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

        function list_symptoms_checkbox($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from symptoms";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));

            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?>
            <div class="parts no_shade_noBorder">
                <input type="checkbox" class="chk_features" name="symptoms[]" value="<?php echo $row['symptoms_id'] ?>" id="  <?php echo $this->_e($row['name']); ?>" /> <label for="<?php echo $this->_e($row['name']); ?>">    <?php echo $this->_e($row['name']); ?> </label>
            </div>




            <?php
            $pages += 1;
        }
    }

//chosen individual field
    function get_chosen_symptoms_name($id) {

        $db = new dbconnection();
        $sql = "select   symptoms.name from symptoms where symptoms_id=:symptoms_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':symptoms_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

    function get_chosen_symptoms_description($id) {

        $db = new dbconnection();
        $sql = "select   symptoms.description from symptoms where symptoms_id=:symptoms_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':symptoms_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['description'];
        echo $field;
    }

    function All_symptoms() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  symptoms_id   from symptoms";
        foreach ($db->query($sql) as $row) {
            $c += 1;
        }
        return $c;
    }

    function get_first_symptoms() {
        $con = new dbconnection();
        $sql = "select symptoms.symptoms_id from symptoms
                    order by symptoms.symptoms_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['symptoms_id'];
        return $first_rec;
    }

    function get_last_symptoms() {
        $con = new dbconnection();
        $sql = "select symptoms.symptoms_id from symptoms
                    order by symptoms.symptoms_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['symptoms_id'];
        return $first_rec;
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category ";
        ?>
        <select class="textbox cbo_account_category" name="cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_category_in_combo_by_cat($cat) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select account_category.account_category_id,   account_category.name from account_category "
                . " where account_category.name='" . $cat . "'";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id,   profile.name from profile";
        ?>
        <select class="textbox cbo_profile"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_image_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select image.image_id,   image.name from image";
        ?>
        <select class="textbox cbo_image"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_reception_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "SELECT * FROM hiv_test.reception
                join profile on profile.profile_id=reception.patient where reception.treated_not_treated='not'";
        ?>
        <select class="textbox cbo_reception" name="cbo_reception"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['reception_id'] . ">" . $row['name'] . ' ' . $row['last_name'] . '=> (' . $row['entry_date'] . ")   </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_diagnosis_in_combo() {
        try {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "SELECT * FROM hiv_test.reception
                join diagnosis on diagnosis.reception=reception. reception_id
                         join profile on profile.profile_id=reception.patient
                         where reception.treated_not_treated='not' 
                          ";
            ?>
            <select class="textbox cbo_diagnosis" name="cbo_diagnosis"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['diagnosis_id'] . ">" . $row['name'] . ' ' . $row['last_name'] . ' => ' . $row['entry_date'] . " </option>";
                }
                ?>
            </select>
            <?php
        } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }
    }

    function get_patient_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "SELECT * FROM hiv_test.reception
                join profile on profile.profile_id=reception.patient";
        ?>
        <select class="textbox cbo_patient" name="cbo_patient"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . ' ' . $row['last_name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_symptom_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select symptoms.symptoms_id,   symptoms.name from symptoms";
        ?>
        <select class="textbox cbo_symptom"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['symptoms_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function list_appointment($min) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from appointment";
        $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));
        ?>
        <table class="dataList_table">
            <thead><tr>

                    <td> appointment </td>
                    <td> Entry Date </td><td> Profile </td>
                    <td>Delete</td><td>Update</td></tr></thead>

            <?php
            $pages = 1;
            while ($row = $stmt->fetch()) {
                ?><tr> 

                    <td>
                        <?php echo $row['appointment_id']; ?>
                    </td>
                    <td class="entry_date_id_cols appointment " title="appointment" >
                        <?php echo $this->_e($row['entry_date']); ?>
                    </td>
                    <td>
                        <?php echo $this->_e($row['profile']); ?>
                    </td>


                    <td>
                        <a href="#" class="appointment_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['appointment_id']; ?>"  data-table="appointment">Delete</a>
                    </td>
                    <td>
                        <a href="#" class="appointment_update_link" style="color: #000080;" data-id_update="<?php echo $row['appointment_id']; ?>" data-table="appointment" >Update</a>
                    </td></tr>
                <?php
                $pages += 1;
            }
            ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_appointment_entry_date($id) {

            $db = new dbconnection();
            $sql = "select   appointment.entry_date from appointment where appointment_id=:appointment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':appointment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['entry_date'];
            echo $field;
        }

        function get_chosen_appointment_profile($id) {

            $db = new dbconnection();
            $sql = "select   appointment.profile from appointment where appointment_id=:appointment_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':appointment_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['profile'];
            echo $field;
        }

        function All_appointment() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  appointment_id   from appointment";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_appointment() {
            $con = new dbconnection();
            $sql = "select appointment.appointment_id from appointment
                    order by appointment.appointment_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['appointment_id'];
            return $first_rec;
        }

        function get_last_appointment() {
            $con = new dbconnection();
            $sql = "select appointment.appointment_id from appointment
                    order by appointment.appointment_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['appointment_id'];
            return $first_rec;
        }

        // <editor-fold defaultstate="collapsed" desc="-------------Addon--------------------">
        function get_catid_by_name($name) {
            $con = new dbconnection();
            $sql = "select account_category.account_category_id from account_category where account_category.name=:name;";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":name" => $name));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $name_res = $row['account_category_id'];
            return $name_res;
        }

        function rec_by_diagnosis($diagnosis) {

            $con = new dbconnection();
            $sql = "SELECT  reception.reception_id  FROM hiv_test.reception
                join diagnosis on diagnosis.reception=reception.reception_id
                where diagnosis.diagnosis_id=:diagnosis";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute(array(":diagnosis" => $diagnosis));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $name_res = $row['reception_id'];
            return $name_res;
        }

        function chart_patients() {


            $database = new dbconnection();
            $db = $database->openconnection();
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = "SELECT min(diagnosis.diagnosis_id) as diagnosis_id,   month(diagnosis.entry_date) as month, min(diagnosis.User) as User, 
                min(diagnosis.reception) as reception ,
                min(profile.profile_id) as profile_id, 
                count(test.test_id) as all_tests,      
                count(test.result) result, min(test.result) as result_name
                FROM hiv_test.reception
                join diagnosis on diagnosis.reception=reception.reception_id
                join profile on profile.profile_id=reception.patient 
                join test on test.diagnosis=diagnosis.diagnosis_id
                group by test.result, month(diagnosis.entry_date)";
            $stmt = $db->prepare($sql);
            $stmt->execute();

//            $mysqli_result = $mysqli->query($sql);
            ?>

        <script type = "text/javascript">
            // Load google charts
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable([
                    ['Test', 'Result'],

        <?php
        while ($row = $stmt->fetch()) {
            echo "['" . $row["result_name"] . "'," . $row["result"] . "],";
        }
        ?>


                ]);
                var options = {
                    title: 'Percentage of Patients test results preparation'
                };
                var chart = new google.visualization.PieChart(document.getElementById('curve_chart'));
                chart.draw(data, options);
            }
        </script>
        <?php
    }

// </editor-fold>
 


    function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }

    function delete() {



        $d = "SELECT min(diagnosis.diagnosis_id) as diagnosis_id,  min(diagnosis.entry_date) as entry_date,  min(diagnosis.User) as User, 
        min(diagnosis.reception) as reception ,
                min(profile.profile_id) as profile_id,  min(profile.name) as name ,  min(profile.last_name) as last_name ,
                min(test.test_id) as test_id,  min(test.name)  as test,  min(test.result) as result,  min(test.comment)  as comment
                FROM hiv_test.reception
                join diagnosis on diagnosis.reception=reception.reception_id
                join profile on profile.profile_id=reception.patient 
                join test on test.diagnosis=diagnosis.diagnosis_id";
    }

}
