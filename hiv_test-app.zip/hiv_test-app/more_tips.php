<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .tip_text{
                /*background-color: #000;*/
                line-height: 26px;
                text-align: justify;
                font-weight: normal;
                color: #000;
            }
            ul li{
                text-align: left;line-height: 26px;
            }

            .tip_image_box{
                position: relative;
                width: 100%;
                height: 180px;



            }
            .tip_image{
                position: absolute;
                background-image: url('web_images/titel1.png');
                background-repeat: no-repeat;
                background-size: 100%;
                width: 100%;
                height: 100%;
            }
            .img1{
                background-image: url('web_images/titel1.png');
            }
            .img2{background-image: url('web_images/titel2.png');}
            .img3{background-image: url('web_images/titel3.png');}
            .margin_layouts{
                margin: 30px auto;
                font-size: 35px;
            }
            
            #bouncing{
                /*background-color: #b44bcb;*/
                position: relative;
            }

            #bouncing::after{
                
                display: block;
                
                width: 0px;   
                height: 50px;
                position: absolute;
                top: 40px;
                left: 80px;
                border-width: 40px;
                border-style: solid;
                content: "   ";
                /*background-color: #cb4bba;*/
                border-bottom-color:  transparent;
                border-right-color:  transparent;
                border-left-color:  transparent;
                border-top-color:  #cb4bba;
            }
            #bouncing a{
                text-decoration: none;
            }
        </style>
    </head>
    <body ><?php include './header_menu.php'; ?>
        <div class="parts eighty_centered " style="background-color: #fff;">
            <div class="parts xx_titles">
                How do I avoid getting HIV during sex?
            </div> 
            <div class="parts no_paddin_shade_no_Border" >
               
                <div class="parts no_paddin_shade_no_Border get_image"id="tip1">

                    <div class="parts no_paddin_shade_no_Border tip_text">
                        How do I avoid getting HIV during sex?
                        HIV is spread through contact with blood or sexual fluids (like semen and vaginal fluids), usually during vaginal and anal sex. So the only 100% certain way to avoid HIV is to not have vaginal or anal sex.

                        But most people do have sex at some point in their lives, so learning about HIV prevention and knowing how to have safer sex is important. Using condoms REALLY lowers your risk of getting HIV. If you’re going to have sex, using condoms every single time is the best way to protect yourself from HIV. There’s also a daily pill you can take — called PrEP — that can help prevent HIV. Your doctor or nurse can tell you if PrEP is right for you.

                        Some sexual activities are safer than others when it comes to getting HIV. These activities are “no risk” — they’ve never caused a reported case of HIV:

                        <ul>
                            <li>  masturbating   </li>
                            <li>     touching your partner’s genitals </li>
                            <li>  rubbing your bodies together (dry humping)   </li>
                            <li>  kissing   </li>
                            <li>  having oral sex with a condom or dental dam   </li>
                            <li> using clean sex toys   </li>
                            <li>  These activities are “lower risk” — they’ve only caused a few reported cases of HIV (out of millions):   </li>
                            <li>  "French” or deep kissing (if the person with HIV has sores or bleeding in their mouth)  </li>
                            <li>  vaginal sex with a condom and/or PrEP  </li>
                            <li>  anal sex with a condom and/or PrEP  </li>
                            <li>  oral sex without a condom or dental dam  </li>
                            <li>  These activities are “high risk” — millions of people get HIV this way:  </li>
                            <li>  These activities are “high risk” — millions of people get HIV this way:  </li>
                            <li>  vaginal sex without a condom or PrEP  </li>
                            <li>  anal sex without a condom or PrEP  </li>
                        </ul>

                    </div>

                    <div class="parts no_shade_noBorder"id="tip2">
                        <div class="parts xx_titles">
                            What Are Some Challenges I Might Face Taking My HIV Medication Every Day?
                        </div>
                        <div class="parts no_paddin_shade_no_Border tip_text">
                            <p> Taking medication every day can be difficult. That is why it is important to understand some of the challenges you may face and to think through how you might address them before they happen. For example, remembering when to take your medication can be complicated. Some medication regimens involve taking several pills every day—with or without food—or before or after other medications. Making a schedule of when and how to take your medicines can be helpful. Or ask your health care provider about the availability of multiple drugs combined into one pill.

                            Other factors can make it difficult to take your HIV medications every day, including:

                            Problems taking medications, such as trouble swallowing pills, can make staying on treatment challenging. Your health care provider can offer tips and ideas for addressing these problems.
                            Side effects from medications, for example, nausea or diarrhea, can make a person not want to take them. Talk to your health care provider. There are medicines or other support, like nutritional counseling to make sure you are getting important nutrients, which can help with the most common side effects. But don’t give up. Work with your health care provider to find a treatment that works for you.
                            A busy schedule. Work or travel away from home can make it easy to forget to take pills.</p><p> Planning ahead can help. Or, it may be possible to keep extra medicines at work or in your car for the times that you forget to take them at home. But make sure you talk to your health care provider—some medications are affected by extreme temperatures, and it is not always possible to keep medications at work.
                            Being sick or depressed. How you feel mentally and physically can affect your willingness to stick to your HIV medications. Again, your health care provider is an important source of information to help with your mental health needs.
                            Alcohol or drug use.</p><p> If substance use is interfering with your ability to keep yourself healthy, it may be time to seek help to quit or better manage it.
                            Treatment fatigue. Some people find that taking their HIV medications becomes harder over time. Every time you see your health care provider, make it a point to talk about staying adherent to your medications.
                            Your health care provider will help you identify barriers to keeping up with your HIV medication regimen and ways to address those barriers. Understanding issues that can make keeping up with your HIV medication regimen difficult will help you and your health care provider select the best treatment for you.

                            Tell your health care provider right away if you’re having taking your HIV medication every day. Together you can identify the reasons why you’re skipping medications and make a plan to address those reasons. Joining a peer support group of others taking HIV medication, or enlisting the support of family and friends, can also help you.
                            </o>  </div>

                    </div > </div>

            </div>
        </div>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>
