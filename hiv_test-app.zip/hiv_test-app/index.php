<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> 
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>    </head>
    <body>
        <?php
        include 'header_menu.php';
        ?>
        <div id="fb-root"></div>
        <script>(function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id))
                    return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));</script>        

        <div class="parts eighty_centered home_pic x_height_4x">

            <div class="parts text_right no_paddin_shade_no_Border push_right">

            </div>
        </div>
        <div class="parts eighty_centered footer">
            Copyrights <?php echo date("Y"); ?>
            <div class="fb-share-button" data-href="https://www.codeguru-pro.net" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.codeguru-pro.net%2Ftests%2Findex.php&amp;src=sdkpreparse">Share</a></div>  
        </div>  
    </body>

    <script src="../hav_rwandaApp/web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
    <script src="web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>

    <script>
            $(document).ready(function () {
                $('.text_right').show("drop", {percent: 200, direction: 'left'}, 2000,
                        function () {
                            $(this).addClass('add_top_margin');
                        });
            });
    </script>

</html>
