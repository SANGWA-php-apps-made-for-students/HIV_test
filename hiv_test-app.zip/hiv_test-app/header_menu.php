<div class="parts  eighty_centered home_header">     
    <div class="parts  no_paddin_shade_no_Border xxx_titles">
       HIV/AIDS MONITORING APPLICATION
    </div>
</div>    
<div class="parts menu eighty_centered">
    <a href="index.php">Home</a>
    <a href="#">About us</a>
    <a href="#">Vision</a>
    <a href="new_tips.php">Tips</a>
    <a href="admin/new_appointment.php">Make an appointment</a>
    

    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>
</div>
