<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <style>
            .tip_text{
                /*background-color: #000;*/
                line-height: 26px;
                text-align: justify;
                font-weight: normal;
                color: #000;
            }
            ul li{
                text-align: left;line-height: 26px;
            }

            .tip_image_box{
                position: relative;
                width: 100%;
                height: 180px;



            }
            .tip_image{
                position: absolute;
                background-image: url('web_images/titel1.png');
                background-repeat: no-repeat;
                background-size: 100%;
                width: 100%;
                height: 100%;
            }
            .img1{
                background-image: url('web_images/titel1.png');
            }
            .img2{background-image: url('web_images/titel2.png');}
            .img3{background-image: url('web_images/titel3.png');}
            .margin_layouts{
                margin: 30px auto;
                font-size: 35px;
            }
            .get_image{
                background-image: url('web_images/login_bg.png');
                background-repeat: no-repeat;
                background-size: 100%;
                height: 600px;
                width: 90%;
            }
            #bouncing{
                background-color: #b44bcb;
                position: relative;
                width: 60%;
            }

            #bouncing::after{

                display: block;

                width: 0px;   
                height: 50px;
                position: absolute;
                top:68px;
                left: 120px;
                border-width: 40px;
                border-style: solid;
                content: "   ";
                /*background-color: #cb4bba;*/
                border-bottom-color:  transparent;
                border-right-color:  transparent;
                border-left-color:  transparent;
                border-top-color:  #b44bcb;
            }
            #bouncing a{
                text-decoration: none;
                color: #fff;
            }
        </style>
    </head>
    <body ><?php include './header_menu.php'; ?>
        <div class="parts eighty_centered " style="background-color: #fff;">
            <div class="parts xx_titles">
                How do I avoid getting HIV during sex?
            </div> 
            <div class="parts no_paddin_shade_no_Border full_center_two_h" >

                <div class="tip_image_box">
                    <div class="tip_image img1"></div>
                    <div class="tip_image img2"></div>
                    <div class="tip_image img3"></div>
                </div>
                
               
            </div>
             <div class=" parts margin_layouts no_shade_noBorder" id="bouncing">
                    <a href="#">Click here the image below</a>
                </div>
            
            <a href="more_tips.php">
                <div class="parts no_paddin_shade_no_Border get_image"id="tip1">  </div>
            </a>
        </div>
        <script src="web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.js" type="text/javascript"></script>
        <script src="web_scripts/ui_scripts/jquery-ui.min.js" type="text/javascript"></script>
        <script src="web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>
