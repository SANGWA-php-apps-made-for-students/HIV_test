<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_reception'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $reception_id = $_SESSION['id_upd'];

            $patient = trim($_POST['txt_patient_id']);
            $new_existing = $_POST['txt_new_existing'];
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $treated_not_treated = $_POST['txt_treated_not_treated'];
            $upd_obj->update_reception($patient, $new_existing, $entry_date, $User, $treated_not_treated, $reception_id);
            unset($_SESSION['table_to_update']);
        }
    } else {

        $patient_status = filter_input(INPUT_POST, 'txt_patient_status');
        $patient = '';
        if ($patient_status == 'new') {
            require_once '../web_db/new_values.php';
            require_once '../web_db/multi_values.php';
            $m = new multi_values();
            $obj = new new_values();
            $name = $_POST['txt_name'];
            $last_name = $_POST['txt_last_name'];
            $username = $name.'_%'.$last_name.'@gmail.com';
            $obj->new_profile(date("y-m-d"), $name, $last_name, "", "", $username, "", 0);
            $last_profile = $m->get_last_profile();
            $patient = $last_profile;
        } else if ($patient_status == 'existing') {
            $patient = trim($_POST['cbo_patient']);
        }
        $new_existing = $_POST['txt_patient_status'];
        $entry_date = date("y-m-d");
        $User = $_SESSION['userid'];
        $treated_not_treated = 'not';

        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $obj->new_reception($patient, $new_existing, $entry_date, $User, $treated_not_treated);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            reception</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .new_existing{
                color: #0040ff;
                margin-left: 100px;
            }
            .change_this_link{
                padding: 10px;
                background-color: #f39d5f;
            }
        </style>
    </head>
    <body>
        <form action="new_reception.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_patient_id"   name="txt_patient_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                reception saved successfully!</div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  reception Registration </div>

                <table class="new_data_table">
                    <tr>
                        <td>
                            <input type="hidden" class="textbox txt_patient_status" value="existing"  required="true" name="txt_patient_status"   />  
                        </td>
                        <td> <a class="new_existing link_new_existing new_p" href="#">New</a>
                            <a class="new_existing link_new_existing existing_p" href="#">Existing</a></td>
                    </tr>
                    <tr class="switch_off_on show_after "><td class="new_data_tb_frst_cols">Patient </td><td> <?php get_patient_combo(); ?>  </td></tr>
                    <tr class="come_on_new off"><td><label for="txt_name">Name </label></td><td> <input type="text"   autocomplete="off"  name="txt_name"  id="txt_name" class="textbox" value="<?php //echo trim(chosen_username_upd()); ?>"   />  </td></tr>
                    <tr class="come_on_new off"><td><label for="txt_last_name">Last name </label></td><td> <input type="text"  autocomplete="off"   name="txt_last_name"  id="txt_username" class="textbox" value="<?php //echo trim(chosen_username_upd()); ?>"   />  </td></tr>

                    <tr class="off"><td><label for="txt_new_existing">New Or Existing </label></td><td> 
                            <input type="text"     name="txt_new_existing"  id="txt_new_existing" class="textbox" value="<?php echo trim(chosen_new_existing_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_reception" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">reception List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_reception();
                $obj->list_reception($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
             $('.existing_p').addClass('change_this_link');
            if (txt_update != '') {
                var patient = '<?php echo chosen_patient_upd(); ?>';
                $('.cbo_patient').val(patient);
                $('#txt_patient_id').val(patient);
            }
            $('.link_new_existing').click(function () {
                $('.link_new_existing').removeClass('change_this_link');
                $(this).addClass('change_this_link');
                $('.show_after').show();
            });
            $('.new_p').click(function () {
                $('.txt_patient_status').val('new');
                $('.switch_off_on').hide();
                $('.come_on_new').show();
                 $('.show_after').hide();

            });
            $('.existing_p').click(function () {
                $('.txt_patient_status').val('existing');
                $('.switch_off_on').show();
                 $('.come_on_new').hide();
            });
        </script>
    </body>
</hmtl>
<?php

function chosen_patient_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            $id = $_SESSION['id_upd'];
            $patient = new multi_values();
            return $patient->get_chosen_reception_patient($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_new_existing_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            $id = $_SESSION['id_upd'];
            $new_existing = new multi_values();
            return $new_existing->get_chosen_reception_new_existing($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_reception_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_reception_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_treated_not_treated_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reception') {
            $id = $_SESSION['id_upd'];
            $treated_not_treated = new multi_values();
            return $treated_not_treated->get_chosen_reception_treated_not_treated($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_patient_combo() {
    $obj = new multi_values();
    $obj->get_patient_in_combo();
}
