<?php

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            appointment</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_appointment.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div> 
            <!--End dialog-->

            <div class="parts eighty_centered off saved_dialog">
                appointment saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box ">
                <div class="parts eighty_centered new_data_title">   Status  </div>
                <div class="parts eighty_centered ">   
                    <div class="parts no_shade_noBorder">
                        Your appoint has been sent, you will use your email as username and 123 as password 
                    </div>
                    <p>
                        <input type="button" class="confirm_buttons" id="go_back" value="OK">    
                    </p>

                </div>
            </div>

        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $('#go_back').click(function () {
                window.location.replace('http://localhost/hiv_test-app/admin/new_appointment.php');
            });
        </script>

        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {

                var profile = '<?php echo chosen_profile_upd(); ?>';
                $('.cbo_profile').val(profile);
                $('#txt_profile_id').val(profile);

            }
        </script>
    </body>
</hmtl>