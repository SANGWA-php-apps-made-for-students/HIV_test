<?php
session_start();
if (isset($_SESSION['table_to_update'])) {
    header('location:new_' . $_SESSION['table_to_update'] . '.php');
}

if (isset($_SESSION['menu_user'])) {
    if ($_SESSION['menu_user']=='receptionist') {
        header('location: new_account.php');
    }else{
        header('location: new_account.php');
    }
}
 