<?php
session_start();
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_test'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $test_id = $_SESSION['id_upd'];

            $name = $_POST['txt_name'];
            $result = $_POST['txt_result'];
            $comment = $_POST['txt_comment'];
            $entry_date = date("y-m-d");

            $User = $_SESSION['userid'];

            $diagnosis = $_POST['cbo_diagnosis'];

            $upd_obj->update_test($name, $result, $comment, $entry_date, $User, $diagnosis, $test_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $name = 'HIV';
        $result = $_POST['txt_result'];
        $comment = $_POST['txt_comment'];
        $entry_date = date("y-m-d");
        $User = $_SESSION['userid'];
        $diagnosis = trim($_POST['cbo_diagnosis']);

        require_once '../web_db/new_values.php';
        require_once '../web_db/multi_values.php';
        require_once '../web_db/updates.php';
        $m = new multi_values();
        $obj = new new_values();
        $upd = new updates();
        $reception_by_diagnosis = $m->rec_by_diagnosis($diagnosis);
        $obj->new_test($name, $result, $comment, $entry_date, $User, $diagnosis);
        ?>  <script> alert('Reception: <?php echo 'Diagnosis ' . $diagnosis . 'Reception: ' . $reception_by_diagnosis; ?>');</script> <?php
        $upd->update_reception_treated('yes', $reception_by_diagnosis);
        get_code();
    }
}

function get_code() {

    $code = "1232123";
    $url = "localhost:8080/Java_web_test/Answer2";
    $postdata = "code=" . $code;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6");
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_REFERER, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_POST, 1);
    $result = curl_exec($ch);

    echo $result;
    curl_close($ch);
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            test</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_test.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_diagnosis_id"   name="txt_diagnosis_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->
            <?php if ($_SESSION['cat'] == 'nurse') {
                ?>
                <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                    <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  
                </div>
            <?php } ?>
            <div class="parts eighty_centered off saved_dialog">
                test saved successfully!</div>


            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  test Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_name">Name </label></td><td> <input type="text"  disabled=""   name="txt_name" required id="txt_name" class="textbox" value="HIV/AIDS"   />  </td></tr>
                    <tr><td><label for="txt_result">Result </label></td><td> 
                            <select name="txt_result" required id="txt_result"   class="textbox">
                                <option></option>
                                <option>Positive</option>
                                <option>Negative</option>
                            </select>
                        </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Diagnosis </td><td> <?php get_diagnosis_combo(); ?>  </td></tr>
                    <tr><td><label for="txt_comment">Comment </label></td><td> <input type="text"     name="txt_comment"   id="txt_comment" class="textbox" value="<?php echo trim(chosen_comment_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_test" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">test List</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_test();
                $obj->list_test($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {
                var diagnosis = '<?php echo chosen_diagnosis_upd(); ?>';
                $('.cbo_diagnosis').val(diagnosis);
                $('#txt_diagnosis_id').val(diagnosis);

            }
        </script>
    </body>
</hmtl>
<?php

function chosen_name_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $name = new multi_values();
            return $name->get_chosen_test_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_result_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $result = new multi_values();
            return $result->get_chosen_test_result($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_comment_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $comment = new multi_values();
            return $comment->get_chosen_test_comment($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_test_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_test_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_diagnosis_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'test') {
            $id = $_SESSION['id_upd'];
            $diagnosis = new multi_values();
            return $diagnosis->get_chosen_test_diagnosis($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_diagnosis_combo() {
    $obj = new multi_values();
    $obj->get_diagnosis_in_combo();
}
