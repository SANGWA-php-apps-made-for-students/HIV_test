<?php
session_start();
if ($_SESSION['cat'] == 'patient') {
    header('location: new_appointment.php');
}
?>


?>
<html>
    <head>
        <title>Dashboard</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        require_once './admin_header.php';
        ?>
        <div class="parts eighty_centered"  style="background-color: #fff;">
            <div class="parts xxx_titles   full_center_two_h no_paddin_shade_no_Border " style="text-transform: capitalize;">
                Welcome <?php
                echo $_SESSION['names'] . ' , ' . $_SESSION['cat'];

                if ($_SESSION['cat'] == 'patient') {
                    header('location: new_appointment.php');
                }
                ?>
            </div> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {
                $('#patient_menu_link').click(function () {

                    alert('clicked');
                    var patient_menu_link = 'c';
                    $.post('handler.php', {patient_menu_link: patient_menu_link}, function (data) {

                    }).complete(function () {
                        window.location.replace('redirect.php');
                    });
                    return false;

                });
            });

        </script>
    </body>
</html>






