<?php
session_start();
require_once '../web_db/multi_values.php';
//$_SESSION['cat'] = 'public';
//$_SESSION['names'] = 'Public user';
if (!isset($_SESSION)) {
    session_start();
}
if (!isset($_SESSION['login_token'])) {
//    header('location:../index.php');
}
if (isset($_POST['send_appointment'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'appointment') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $appointment_id = $_SESSION['id_upd'];
            $entry_date = date("y-m-d");
            $profile = $_POST['txt_profile_id'];
            $upd_obj->update_appointment($entry_date, $profile, $appointment_id);
            unset($_SESSION['table_to_update']);
        }
    } else {

        require_once '../web_db/new_values.php';
        require_once '../web_db/multi_values.php';
        $m = new multi_values();
        $obj = new new_values();
        $name = $_POST['txt_name'];
        $last_name = $_POST['txt_last_name'];
        $username = $_POST['txt_email'];
        $obj->new_profile(date("y-m-d"), $name, $last_name, "", "", $username, "", 0);
        $last_profile = $m->get_last_profile();
        $patient = $last_profile;

        //Create an account
        $account_category = $m->get_catid_by_name('patient');
        $date_created = date('y-m-d');
        $password = '123';
        $is_online = 'no';
        $obj->new_account($account_category, $date_created, $last_profile, $username, $password, $is_online);

        //New appointment
        $entry_date = date("y-m-d");
        $obj->new_appointment($entry_date, $last_profile);

        //Save the recepption (he receives himself)
        $new_existing = 'new';
        $User = $m->get_last_account();
        $treated_not_treated = 'not';
        $last_user = $m->get_last_account();
        $obj->new_reception($patient, $new_existing, $entry_date, $last_user, $treated_not_treated);
        ?> 
        <script>
            window.location.replace('http://localhost/hiv_test-app/admin/After_appointment.php');
        </script> <?php
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            appointment</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_appointment.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
            include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div> 
            <!--End dialog-->
            <div class="parts eighty_centered off saved_dialog">
                appointment saved successfully!
            </div>
            <?php
            if (isset($_SESSION)) {
                if (!isset( $_SESSION['cat']) ){
                   ?>
                    <div class="parts eighty_centered new_data_box">
                        <div class="parts eighty_centered new_data_title">  appointment Registration </div>
                        <table class="new_data_table">
                            <tr class="come_on_new "><td><label for="txt_name">Name </label></td><td> <input type="text"   autocomplete="off" required name="txt_name"  id="txt_name" class="textbox" value="<?php //echo trim(chosen_username_upd());                 ?>"   />  </td></tr>
                            <tr class="come_on_new "><td><label for="txt_last_name">Last name </label></td><td> <input type="text"  autocomplete="off"  required name="txt_last_name"  id="txt_username" class="textbox" value="<?php //echo trim(chosen_username_upd());                 ?>"   />  </td></tr>
                            <tr class="come_on_new "><td><label for="txt_email">Email </label></td><td> <input type="email"  autocomplete="off" required  name="txt_email"  id="txt_email" class="textbox" value="<?php //echo trim(chosen_username_upd());                 ?>"   />  </td></tr>
                            <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_appointment" value="Save"/>  </td></tr>
                        </table>
                    </div><?php
                }
            }
            ?>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">My appointments</div>
                <?php
                if (isset($_SESSION['login_token'])) {
                    $obj = new multi_values();
                    $first = $obj->get_first_reception();
                    $obj->list_reception_by_profile($_SESSION['profile_id']);
                } else {
                    echo 'If you want to view your appointment <a href="../login.php">Click here</a>';
                }
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script>
            var txt_update = $('#txt_shall_expand_toUpdate').val();
            if (txt_update != '') {
                var profile = '<?php echo chosen_profile_upd(); ?>';
                $('.cbo_profile').val(profile);
                $('#txt_profile_id').val(profile);
            }
        </script>
    </body>
</hmtl>
<?php

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'appointment') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_appointment_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'appointment') {
            $id = $_SESSION['id_upd'];
            $profile = new multi_values();
            return $profile->get_chosen_appointment_profile($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_profile_combo() {
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}
