<?php


function admin_menu() {
    ?>
    <a id = "patient_menu_link" href="#">Patient</a>
    <a id = "receptionist_menu_link" href="#">Receptionist</a>  
    <a href = "new_lab_tech.php">Nurse</a>
    <a href = "new_Doctor.php">Doctor</a>
    <a href = "new_account_category.php">account category</a>
    <a href = "charts.php">Report</a>
    <?php
}

function receptionist() {
    ?>
    <a href = "new_reception.php">reception</a>
    <a href = "new_symptoms.php">symptoms</a>

    <?php
}

function doctor_menu() {
    ?> <a href = "new_symptoms.php">symptoms</a>
    <a href = "new_diagnosis_symptoms.php">Diagnosis</a>
    <a href = "new_test.php">test</a>
      <a href = "new_appointment.php">Appointments</a>
    <?php
}

function nurse_menu() {
    ?><a href = "new_diagnosis_symptoms.php">Diagnosis</a>
    <a href = "new_test.php">test</a>
    <a href = "new_symptoms.php">symptoms</a>
<a id = "patient_menu_link" href = "new_account.php">Patient</a>
    <?php
}
function public_menu() {
    ?>
    <a href = "#">About us</a>
    <a href = "#">Vision</a>
    <a href = "../new_tips.php">Tips</a>
    <a href = "new_appointment.php">My Appointments</a>
    <?php
}
?>
<div class = "parts home_header  eighty_centered ">
    <div class = "parts   no_paddin_shade_no_Border xxx_titles">
        HIV/AIDS MONITORING APPLICATION
    </div>
</div>
<div class = "parts menu eighty_centered">
    <a href = "../index.php">Home</a>
   
    <?php
    if (isset($_SESSION)) {
        if (isset($_SESSION['cat'])) {
            ?> <a href = "admin_dashboard.php">Dashborad</a>
                <?php
            if ($_SESSION['cat'] == 'admin') {
                admin_menu();
            } else if ($_SESSION['cat'] == 'receptionist') {
                receptionist();
            } else if ($_SESSION['cat'] == 'doctor') {
                doctor_menu();
            } else if ($_SESSION['cat'] == 'nurse') {
                nurse_menu();
            }
             ?>
        <div class = "parts two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href = "../logout.php"><?php echo '(' . $_SESSION['cat'] . ') ' ?>Logout</a>
        </div>     
        <?php
        }else{
            public_menu();
        }
       
    }
    ?>



</div>
